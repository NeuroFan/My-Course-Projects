function res=spc_XOR(A,B)
res(1:length(A))=dec2bin(0);
for i=1:length(A)
    if A(i)~=B(i) 
        res(i)='1' ;
    else
        res(i)='0';
    end
end