function tDftr(im)
imfourier=fft2(im);
imfourier=fftshift(imfourier);
imfo_abs=abs(imfourier);
M=max(max(imfo_abs));
[c d]=size(imfo_abs);
for i=1:c
   for j=1:d
       imfo_abs_scale(i,j)=(imfo_abs(i,j)/M)*255;
   end
end
imshow(imfo_abs_scale);
colormap(hot)
title('Specrum Of the image')
end
