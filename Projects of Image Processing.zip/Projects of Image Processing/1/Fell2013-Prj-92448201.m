clear;clc
im=uint8(rgb2gray(imread('lena.tiff')));
noql=input('WHICH LEVEL OF QUANTIZATION WOULD YOU LIKE? 1 to 256  ');
if isnumeric(noql)
ql=256-noql;
if ql<=0 
    ql=1; end
im2=im/ql;   % NOW QUATIZED    247/10=24
im2=im2*ql;  % BACK TO STANDARD VERSION OF REPRESENTATION 24*10=240
end 

display('So you want to see your image in a ') ;
   display ([num2str(256-ql),' intensity level format']);
nothing=input('Enter');
imshow(im);figure;
imshow(im2);figure;

one_D_im=im(:);
one_D_im2=im2(:);
plot(one_D_im(1000:5000));figure;
plot(one_D_im2(1000:5000));
