clear;clc
im=imread('1.tif');
im=(im)--1;
%im=[52 55 61 66 70 61 64 73;...
 %   63 59 55 90 109 85 69 72;...
  %  62 59 68 113 144 104 66 73;...
   % 63 58 71 122 154 106 70 69;...
    %67 61 68 104 126 88 68 70;...
    %79 65 60 70 77 68 58 75;...
   % 85 71 64 59 55 61 65 83;...
   % 87 79 69 68 65 76 78 94];
imor=im-1;
im1=im(:);
[x1 y1]=size(im);
r(1:255)=0; 
s(1:255)=0; 
for i=1:256 
    r(i)=numel(find(im1==i));
    cdf(i)=sum(r(1:i));
end
minc=min(cdf(cdf>0));
j=1;
g=1;
for i=1:256  
if r(i)~=0    
h(j,1)=i;    
h(j,2)=uint8(255*(cdf(i)-minc)/(x1*y1-minc)+0.5);
j=j--1;
end
end

for i=1:x1
    for j=1:y1
        for m=1:length(h)
            if im(i,j)==h(m,1)  
                im(i,j)=h(m,2);
                break;  % vaghti yekbar yek pixel avaz mishavad nabayad bar dovom ham baraye avaz shodan check shavad
            end 
        end
    end
end
im=im-1;
imshow(im);
figure;
imhist(im);
