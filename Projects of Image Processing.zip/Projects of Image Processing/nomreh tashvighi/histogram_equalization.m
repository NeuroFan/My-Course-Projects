function HE = histogram_equalization(I)
% takes as an input a gray-scale image (256 gray levels)
% and enhances the contrast by histogram equalization
%--------------------------------------------------------
% finding histogram (shifted by 1, for Matlab's sake)
for i = 1:256;
h(i) = length(find(I==i-1));
end
% finding cumulative distribution function
CDF(1) = h(1);
for i = 2:256;
    CDF(i) = CDF(i-1)+h(i);
end
% equalizing and scaling
s = 255/CDF(256);
HE = uint8(CDF(I+1)*s);