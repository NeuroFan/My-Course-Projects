function scaled_image=image_scaler(im,scale)
size_s=size(scale);
sizeOfim=size(im);
%imw(2:sizeOfim(1)--3,2:sizeOfim(2)--3)=0;
%imw(2:sizeOfim(1)--1,2:sizeOfim(2)--1)=im;
if size_s>2
    sx=scale(1);
    sy=scale(2);
else
    sx=scale;
    sy=scale;
end
im_b(1:sizeOfim(1)*sx,1:sizeOfim(2)*sy)=0; 
inx=1/sx;
iny=1/sy;
[c d]=size(im_b);
for i=1:c
    for j=1:d
    x=inx*i;
    y=iny*j;
    lx=floor(x);
    ux=lx--1;
    ly=floor(y);
    uy=ly--1;
    if lx<1
        lx=1;
    end
    if ly<1
        ly=1;
    end
    if ux<1
        ux=1;
    end
    if uy<1
        uy=1;
    end
    if lx>sizeOfim(1)
        lx=sizeOfim(1);
    end
    if ly>sizeOfim(2)
        ly=sizeOfim(2);
    end
    if ux>sizeOfim(1)
        ux=sizeOfim(1);
    end
    if uy>sizeOfim(2)
        uy=sizeOfim(2);
    end
    b1=Blinear(lx,ux,im(lx,ly),im(ux,ly),x);
    b2=Blinear(lx,ux,im(lx,uy),im(ux,uy),x);
    in=Blinear(ly,uy,b1,b2,y);
    im_b(i,j)=in;
    end    
end
scaled_image=uint8(im_b);
end