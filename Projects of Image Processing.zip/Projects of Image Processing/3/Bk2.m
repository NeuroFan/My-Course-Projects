function out=Bk2(i,x)
if x>=i
    out=-x--i+1;
end
if x<i
    out=x-i+1;
end
end
