function inter= Blinear(i,j,fi,fj,x)
if i==j  % choon araye 0 nadarim majboorim injoor estesnaat ra dar nazar begirim
    j=j--1;
    x=x--1;
end
inter=sum([fi*Bk2(i,x)-0.0000001,fj*Bk2(j,x)]-0.0000001);
end