clear;clc
x=[3 4;4 3;4 4;4 5;5 4;5 5;5 6;6 5];
mx=mean(x);
cx(2,2)=0;
for i=1:8
x1(i,:)=x(i,:)-mx;
end
for i=1:8
    x2(:,:,i)=x1(i,:)'*x1(i,:);
end
for i=1:8
cx(1,1)=cx(1,1)+x2(1,1,i);
cx(1,2)=cx(1,2)+x2(1,2,i);
cx(2,1)=cx(2,1)+x2(2,1,i);
cx(2,2)=cx(2,2)+x2(2,2,i);
end
cx=cx/i;
[A lamdas]=eigs(cx);
y=A*x1';
