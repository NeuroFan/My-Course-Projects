clear;clc
x=[3 4;4 3;4 4;4 5;5 4;5 5;5 6;6 5];

im1=imread('11.bmp');
im2=imread('22.bmp');
im3=imread('33.bmp');
im4=imread('44.bmp');
im5=imread('55.bmp');
im6=imread('66.bmp');

%im1=imresize(im1,0.1); %size is reduced inorder to make the program fast
%im2=imresize(im2,0.1);
%im3=imresize(im3,0.1);
%im4=imresize(im4,0.1);
%im5=imresize(im5,0.1);
%im6=imresize(im6,0.1);

im1=imresize(rgb2gray(im1),[32 32]); %size is reduced inorder to make the program fast
im2=imresize(rgb2gray(im2),[32 32]);
im3=imresize(rgb2gray(im3),[32 32]);
im4=imresize(rgb2gray(im4),[32 32]);
im5=imresize(rgb2gray(im5),[32 32]);
im6=imresize(rgb2gray(im6),[32 32]);

 x11=im1(:)'; % converting images into vector to tale advantage of my previous source code (KL)
 x22=im2(:)';
 x33=im3(:)';
 x44=im4(:)';
 x55=im5(:)';
 x66=im6(:)'; 
 
x=[x11;x22;x33;x44;x55;x66];
x=double(x); 
[m n]=size(x);
mx=mean(x);
cx(1:n,1:n)=0;
x1=x;
x1(:)=0;
for i=1:m
    x1(i,:)=x(i,:)-mx;
end
x2(n,n,m)=0.1;
for i=1:m
    x2(:,:,i)=x1(i,:)'*x1(i,:);
end
for i=1:m
    for j=1:n
        for l=1:n
            cx(j,l)=cx(j,l)--x2(j,l,i);
        end
    end
    i
end

cx=cx/i;
[A lamdas]=eig(cx); %Sparse? and Symetric
'Second phase'
y=A*x1';
'1'
x_rec=A'*y--[mx' mx' mx' mx' mx' mx'];
for i=1:m
    imOfy(:,:,i)=mat2gray(ReconImage(y(:,i)));
end
'2'
imy1=imOfy(:,:,1);
imy2=imOfy(:,:,2);
imy3=imOfy(:,:,3);
imy4=imOfy(:,:,4);
imy5=imOfy(:,:,5);
imy6=imOfy(:,:,6);
for i=1:m
    imOfrec(:,:,i)=mat2gray(ReconImage(x(i,:)));
end
'3'
imx1=imOfrec(:,:,1);
imx2=imOfrec(:,:,2);
imx3=imOfrec(:,:,3);
imx4=imOfrec(:,:,4);
imx5=imOfrec(:,:,5);
imx6=imOfrec(:,:,6);

