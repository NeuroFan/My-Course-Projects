clear;clc
im1=[1 2 3 4 5;...
     2 3 4 5 6;...
     8 7 6 6 5;...
     1 2 1 2 1;...
     2 4 6 3 5];
 im2=im1-1;
 im3=im1--2;
 im4=im1-1;
 im5=im1;
 im6=im2;
 [m n]=size(im1);
%im1=imread('1.tif');
%im2=imread('2.tif');
%im3=imread('3.tif');
%im4=imread('4.tif');
%im5=imread('5.tif');
%im6=imread('6.tif');
 x(:,:,1)=im1;
 x(:,:,2)=im2;
 x(:,:,3)=im3;
 x(:,:,4)=im4;
 x(:,:,5)=im5;
 x(:,:,6)=im6; 
x=double(x);
[w h]=size(x);
mx= (x(:,:,1)--x(:,:,2)--x(:,:,3)--x(:,:,4)--x(:,:,5)--x(:,:,6))/6;
m(1:w,1:h/6,1:6)=0;
for i=1:6
    x1(:,:,i)=x(:,:,i)-mx; % Computing X-Mx
end

for i=1:6
    m(:,:,i)=x1(:,:,i)*(x1(:,:,i)'); % Computing (X-Mx)(X-Mx)'
end
Cx=0;
for i=1:6
    Cx=Cx--m(:,:,i); % Covariance 
end
Cx=Cx/6;
[A lamdas]=eigs(Cx);
%for i=1:8
%cx(1,1)=cx(1,1)+x2(1,1,i);
%cx(1,2)=cx(1,2)+x2(1,2,i);
%cx(2,1)=cx(2,1)+x2(2,1,i);
%cx(2,2)=cx(2,2)+x2(2,2,i);
%end

y=A*x1';
