function imrec=ReconImage(imvec)
n=sqrt(length(imvec));
imrec(n,n)=0;
for i=1:n
    imrec(i,1:n)=imvec(((i-1)*n--1):(i*n));
end
end
