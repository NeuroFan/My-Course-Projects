clear all;clc
x=[3 4;4 3;4 4;4 5;5 4;5 5;5 6;6 5];

im1=imread('1.tif');
im2=imread('2.tif');
im3=imread('3.tif');
im4=imread('4.tif');
im5=imread('5.tif');
im6=imread('6.tif');
siz=200;
im1=imresize(im1,[siz siz]); %size is reduced inorder to make the program fast
im2=imresize(im2,[siz siz]);
im3=imresize(im3,[siz siz]);
im4=imresize(im4,[siz siz]);
im5=imresize(im5,[siz siz]);
im6=imresize(im6,[siz siz]);

 x11=im1(:)'; % converting images into vector to tale advantage of my previous source code (KL)
 x22=im2(:)';
 x33=im3(:)';
 x44=im4(:)';
 x55=im5(:)';
 x66=im6(:)';
 
x=[x11;x22;x33;x44;x55;x66]';
x=double(x); 
[m n]=size(x);
mx=mean(x);
x1=x;
x1(:)=0;


cx=cov(x);
[A lamdas]=eig(cx); %Sparse? and Symetric
y=A'*x';
x_rec=A*y;
for i=1:m
x_rec(:,i)=x_rec(:,i)+mx' ;
end
for i=1:6
    imOfy(:,:,i)=mat2gray(ReconImage(y(i,:)));
end
imy6=imOfy(:,:,1);
imy5=imOfy(:,:,2);
imy4=imOfy(:,:,3);
imy3=imOfy(:,:,4);
imy2=imOfy(:,:,5);
imy1=imOfy(:,:,6);
for i=1:6
    imOfrec(:,:,i)=mat2gray(ReconImage(x(:,i)));
end
imx1=imOfrec(:,:,1);
imx2=imOfrec(:,:,2);
imx3=imOfrec(:,:,3);
imx4=imOfrec(:,:,4);
imx5=imOfrec(:,:,5);
imx6=imOfrec(:,:,6);
imshow(uint8(imy1))
figure;imshow((mat2gray(imy2)));
figure;imshow((mat2gray(imy3)));
figure;imshow((mat2gray(imy4)));
figure;imshow((mat2gray(imy5)));
figure;imshow((mat2gray(imy6)));
