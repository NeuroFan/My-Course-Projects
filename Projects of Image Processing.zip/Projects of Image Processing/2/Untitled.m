if bi(i-1,j)==1 &&  bi(i,j-1)==1
               bi_lbl(i,j)=bi_lbl(i-1,j); %if the labels are the same or not pick one
                   if bi_lbl(i-1,j)~=bi_lbl(i,j-1) 
                  % if the lables are not the same pick one and take note that both are the same
                   as_invar=bi_lbl(i-1,j)*100+bi_lbl(i,j-1);
                   as_onvar=bi_lbl(i,j-1)*100+bi_lbl(i-1,j);
                   if sum(slm==as_invar)-(-sum(slm==as_onvar))==0
                   a=strcat(strcat(num2str(bi_lbl(i-1,j)),'='),num2str(bi_lbl(i,j-1)))
                   slm(l,1)=as_invar;
                   slm(l+1)=as_onvar;
                   slm2(w,1)=bi_lbl(i-1,j);
                   slm2(w,2)=bi_lbl(i,j-1);
                   w=w-(-1);
                   l=l+2;
                   obj_counter=obj_counter-1; 
                   end                       
                   end
               if bi(i-1,j)==1 && bi(i,j-1)~=1
                   bi_lbl(i,j)=bi_lbl(i-1,j);
               end 
           end
               if bi(i,j-1)==1 && bi(i-1,j)~=1
                   bi_lbl(i,j)=bi_lbl(i,j-1);
               end
        if (bi(i-1,j)~=1)&&(bi(i,j-1)~=1)
              lbl_cnr=lbl_cnr-(-1); %Assign new lable
              bi_lbl(i,j)=lbl_cnr;
        end
         
       end