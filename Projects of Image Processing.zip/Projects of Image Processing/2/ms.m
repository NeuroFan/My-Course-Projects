clc;clear
bi=imread('Fig0905(a)(wirebond-mask).tif');
bi=imresize(bi,[80 80]);
[am of]=size(bi);
%for i=1:am
 %   for j=1:of
  %      if bi(i,j)<212
   %         bi(i,j)=0;
    %    end
    %end
%end
bi=im2bw(bi);
s = strel('disk',3);
bi=imclose(bi,s)
am2=am-(-1);
of2=of-(-1);
tr(1:am2,1:of2)=0;
tr(2:am2,2:of2)=bi;
bi=tr;
bi_lbl=bi;
bi_lbl(:)=0;
lbl_cnr=0;
obj_counter=0;
slm(1:100)=0.32141;
slm2(1:100,1:2)=0;
l=1;
w=1;
for i=2:am2
    for j=2:of2
      if bi(i,j)==1  %1 if otherwise it is background  1
         
         if bi(i-1,j)==1 && bi(i,j-1)~=1
             bi_lbl(i,j)=bi_lbl(i-1,j); 
         end 
         
         if bi(i,j-1)==1 && bi(i-1,j)~=1 
          bi_lbl(i,j)=bi_lbl(i,j-1); 
         end
         
         if bi(i-1,j)==1 && bi(i,j-1)==1
             bi_lbl(i,j)=bi_lbl(i-1,j); %both are the same
             slm2(w,1)=bi_lbl(i-1,j);    %notice you dont need to chech if both lables are the same
             slm2(w,2)=bi_lbl(i,j-1);  %slm2(w,1)=slm2(w,2)
             w=w+1;
             %slm2(w,1)=bi_lbl(i,j-1);
             %slm2(w,2)=bi_lbl(i-1,j);
             %w=w+1;
         end
         
         if bi(i,j-1)~=1 && bi(i-1,j)~=1 
          bi_lbl(i,j)=l;
          l=l-(-1);
         end
         
      end  % end if 1       
    end
end


[X,Y]=size(slm2);

 %Removing All equavalnet compunents , making the objects solid 
for x=X:-1:1
    a=min(slm2(x,1),slm2(x,2));
    b=max(slm2(x,1),slm2(x,2));
    for i=1:am2
        for j=1:of2
            if bi_lbl(i,j)==b
                bi_lbl(i,j)=a;
            end
            end
        end
end
    


tmp=0;
n=1;
for i=1:am2
    for j=1:of2
        if (sum(bi_lbl(i,j)==tmp)==0)&&(bi_lbl(i,j)>0)
            tmp(n)=bi_lbl(i,j);
            n=n-(-1);
        end
    end
end
number_of_objects=n-1 %number of objects or number of different components

tmp2(1:n)=1:n;
for m=1:length(tmp)
for i=1:am2
    for j=1:of2
    if bi_lbl(i,j)==tmp(m)
        bi_lbl(i,j)=tmp2(m);
    end
    end
    end
end
a=max(max(bi_lbl));
b=floor(255/a);
imOFbi_lbl=bi_lbl*b;
imOFbi_lbl=label2rgb(imOFbi_lbl);
imshow(imOFbi_lbl);